$('.responsive-button').on('click', function(){
  $('.mainNav > ul').slideToggle();
  if($('.mainNav > ul').is(':visible')){
    $('body').toggleClass('responsive-menu-open');
  }
});


$( document ).ready(function() {

// const registerVideo = (bound, video) => {
//   bound = document.querySelector(bound);
//   video = document.querySelector(video);
//   const scrollVideo = ()=>{
//     if(video.duration) {
//       const distanceFromTop = window.scrollY + bound.getBoundingClientRect().top;
//       const rawPercentScrolled = (window.scrollY - distanceFromTop) / (bound.scrollHeight - window.innerHeight);
//       const percentScrolled = Math.min(Math.max(rawPercentScrolled, 0), 1);
      
//       video.currentTime = video.duration * percentScrolled;
//     }
//     requestAnimationFrame(scrollVideo);
//   }
//   requestAnimationFrame(scrollVideo);
// }


// registerVideo("#bound-one", "#bound-one video");
AOS.init({
   once: true
});

$('.scrollDiv').on('click',function(){
  $('html,body').animate({scrollTop:jQuery(this.hash).offset().top},800);
});


$('.eventSlider-Wrap').slick({
  dots: false,
  infinite: false,
  slidesToShow: 3,
  slidesToScroll: 1,
  responsive: [
    {
      breakpoint: 1024,
      settings: {
        slidesToShow: 3
      }
    },
    {
      breakpoint: 992,
      settings: {
        slidesToShow: 2
      }
    },
    {
      breakpoint: 600,
      settings: {
        slidesToShow: 2
      }
    },
    {
      breakpoint: 599,
      settings: {
        slidesToShow: 1.2
      }
    },
    {
      breakpoint: 480,
      settings: {
        slidesToShow: 1.2
      }
    }
  ]
});

$('.searchRight  button').on('click', function(){
  $('body').toggleClass('sideSearchActive');
  $('#searchLeft').toggleClass('open');
});

$('.search-close').on('click', function(){
  $('body').toggleClass('sideSearchActive');
  $('#searchLeft').toggleClass('open');
});

$('.sideBarClose').on('click', function(){
  $('body').toggleClass('storySideBarClose');
  $('.sideStoriesWrap').toggleClass('close');
});

$('.openStorySidebar').on('click', function(){
  $('body').toggleClass('storySideBarClose');
  $('.sideStoriesWrap').toggleClass('close');
});

});


$(window).scroll(function() {
if ($(this).scrollTop() > 20){  
    $('.topHeader').addClass("sticky");
  }
  else{
    $('.topHeader').removeClass("sticky");
  }
});